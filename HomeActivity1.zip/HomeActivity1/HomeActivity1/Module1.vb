﻿Module Module1

    Sub Main()

        'Inputs
        Dim cols As Integer
        Dim rows As Integer

        Console.WriteLine("Enter Number of Rows : ")
        rows = CInt(Console.ReadLine())
        Console.WriteLine("Enter Number of Columns : ")
        cols = CInt(Console.ReadLine())

        Dim table(rows, cols) As Integer
        Dim numbers As String

        Console.WriteLine("Enter " & ((rows + 1) * (cols + 1)) & " Numbers, Separated by space")
        numbers = Console.ReadLine()
        numbers = numbers + " "

        'getting 2D Array Values

        Dim c As String
        Dim num = ""

        For i = 0 To numbers.Length - 1
            c = numbers(i)
            If Not c = " " Then
                num = num + c
            Else
                For j = 0 To rows
                    For k = 0 To cols
                        If table(j, k) = 0 Then
                            table(j, k) = CInt(num)
                            num = ""
                            GoTo cont
                        End If
                    Next
                Next
            End If
cont:

        Next

        ' Getting the sum
        Dim sCols(cols) As Integer
        Dim sRows(rows) As Integer

        Dim fCols = 0
        Dim fRows = 0

        For i = 0 To rows
            For j = 0 To cols
                sRows(i) = sRows(i) + table(i, j)
            Next
        Next

        For i = 0 To cols
            For j = 0 To rows
                sCols(i) = sCols(i) + table(j, i)
            Next
        Next


        ' Display output
        For i = 0 To rows
            For j = 0 To cols
                Console.Write(table(i, j))
                If table(i, j) <= 9 Then
                    Console.Write("      ")
                ElseIf table(i, j) <= 99 Then
                    Console.Write("     ")
                ElseIf table(i, j) <= 999 Then
                    Console.Write("    ")
                End If
            Next
            Console.WriteLine(" = " & sRows(i))
        Next

        For i = 0 To cols
            Console.Write("=      ")
        Next
        Console.WriteLine("")

        For i = 0 To cols
            Console.Write(sCols(i))
            If sCols(i) <= 9 Then
                Console.Write("      ")
            ElseIf sCols(i) <= 99 Then
                Console.Write("     ")
            ElseIf sCols(i) <= 999 Then
                Console.Write("    ")
            End If
        Next

        Console.ReadKey()

    End Sub

End Module
